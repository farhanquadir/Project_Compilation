The necessary packages to train this includes keras2.0, tensorflow1.15, python 3.6, pandas, numpy, sklearn, seaborn, nltk, gensim, and matplotlib.
Other packages may be needed accordingly. 
Please make sure the appropriate data files are there. Also we have not included the saved models or any code for that. The final predictor uses the saved models. The final predictor code has been excluded.
 
To run any model:
python <python_code_file.py>
