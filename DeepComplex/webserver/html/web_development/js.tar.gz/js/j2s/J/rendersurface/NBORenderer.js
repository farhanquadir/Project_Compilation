Clazz.declarePackage ("J.rendersurface");
Clazz.load (["J.rendersurface.MolecularOrbitalRenderer"], "J.rendersurface.NBORenderer", null, function () {
c$ = Clazz.declareType (J.rendersurface, "NBORenderer", J.rendersurface.MolecularOrbitalRenderer);
});
