Clazz.declarePackage ("J.rendersurface");
Clazz.load (["J.rendersurface.IsosurfaceRenderer"], "J.rendersurface.PmeshRenderer", null, function () {
c$ = Clazz.declareType (J.rendersurface, "PmeshRenderer", J.rendersurface.IsosurfaceRenderer);
});
