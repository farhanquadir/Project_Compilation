Clazz.declarePackage ("JSV.common");
Clazz.declareInterface (JSV.common, "XYScaleConverter");
