import matplotlib.pyplot as plt
import sys
import numpy as np
file=sys.argv[1]
ar=plt.imread(file)
plt.imshow(ar)

